/**
 * 
 */document.querySelector('.carousel-c-next').addEventListener("click", function () {
    document.qu('.carousel slide').style.transform = 'translate(-100vw)'
})